Thank you for selecting WinCraps�!

WinCraps is a fully featured craps simulator designed to run in a Windows environment.  Highly configurable game elements allow you to customize the table to simulate your favorite casino or just to suit yourself.  An extensive array of automatic features can assist your manual play or allow you to run "Auto-Betting" scripts in fully automatic "Hyper-Drive" mode for up to 100 million rolls.  WinCraps includes an abundance of statistics and graphs, as well as Hot-Keys and a comprehensive help file. WinCraps is the game with the power you've been searching for!

________________________________________________________
To install WinCraps:


If you have a WinCraps CD-Rom:

1) Place your WinCraps CD-Rom in your disk drive.
      - If the installation program begins automatically skip to step 5 below.
2) Click the "Start" button on your taskbar.
3) Select "Run".
4) Enter the drive letter of your CD-ROM and the file WCINSTALL.EXE then click OK.
      - For example,  D:\WCINSTALL.EXE
5) A green craps table with a small welcome message will appear. Click the "Install" button.
6) A folder-selection window will appear. This designates where WinCraps' files will be installed on your computer.
      - Choose an existing folder, enter a new folder, or just accept the default folder of C:\WINCRAPS
7) After the game files have been installed, you'll be presented with opportunities to create shortcuts.
8) That's it. You may now remove the CD-Rom and play the game.



If you downloaded WinCraps from the internet:

1) Click the "Start" button on your taskbar.
2) Select "Run".
3) Enter the path to the location of the downloaded file WINCRAPS.EXE and click OK.
      - For example,  C:\MYDOWNLOADS\WINCRAPS.EXE
      - This is a single "zipped" (compressed) file which contains all of WinCraps' game and installation files.
4) A small window with three buttons will appear. Press the button marked "Setup".
      - The game files will be extracted to a temporary folder.
5) A green craps table with a small welcome message will appear. Click the "Install" button.
6) A folder-selection window will appear. This designates where WinCraps' files will be installed on your computer.
      - Choose an existing folder, enter a new folder, or just accept the default folder of C:\WINCRAPS
7) After the game files have been installed, you'll be presented with opportunities to create shortcuts.
8) That's it. You may now play the game.

If you're unable to install WinCraps using the automated installation program, you can manually install it by extracting the game files from WINCRAPS.EXE using any standard zip program.  In this event, if you're installing WinCraps into the same location as an earlier version of WinCraps, be sure to overwrite all files.


All of WinCraps' files are copied to the single folder which you specify during installation.  There are no hidden files and no changes to your system registry or configuration.  When installation is complete (or if you should cancel the installation) any temporary files and folder will be deleted.

________________________________________________________
To uninstall WinCraps:

Simply delete the folder containing WinCraps' game files.  

________________________________________________________
To play WinCraps:

Simply invoke the game from the desktop or program menu shortcut.

If you did not allow WinCraps' installation program to create a desktop or program menu shortcut for you, or if you manually extracted the game files using a zip program, then you must locate and run the file WC50M.EXE.  You'll find this file in the folder you specified during installation or extraction.

- Click the "Start" button on your taskbar
- Select "Run"
      - Enter the path to the location of the game file
      - For example,  C:\WINCRAPS\WC50N.EXE

If you did not allow WinCraps' installation program to create a desktop shortcut but would like one now, you can create one as follows:

- Right-click the mouse-pointer over an open area of your Windows desktop
- Select "New"
- Select "Shortcut"
      - Enter the path to the location of the game file
      - For example,  C:\WINCRAPS\WC50N.EXE
- Click "Next"
- Enter a name for the shortcut, e.g. "WinCraps"
- Click "Finish"

If you're upgrading from an earlier version, a list of changes can be found in the file HISTORY.TXT.

________________________________________________________
Activating your registered version:

If you've registered WinCraps, you'll need to complete your registration by entering your name and registration number into game after installation.  To do this, first start the game.  Then while the "About WinCraps" screen is present (this automatically appears every time you start the game) press the letter "R" on your keyboard.  Two boxes (not the order form) will then appear where you can enter your registration information.  Make sure you enter your name and number EXACTLY as they were provided to you - taking care to use the same upper and lower case letters, punctuation and spacing.  Press the TAB key to move between the selections, and press the ENTER key when you're done.  If successful, your name will appear over some swirling chips.

________________________________________________________
Benefits of Registration:

- Unlimited usage
- No "Order Form" reminders
- Unrestricted use of the Hyper-Drive
- Ability to save probability files
- Discounts on upgrades
- Discounts on other Cloud City Software products

________________________________________________________
Ordering:

Ordering the registered version of WinCraps is best accomplished over the internet at http://www.cloudcitysoftware.com  There you'll find options which will allow you to enter credit card information over a secure server.  Other options include completing the order form which can be found within the game under the help menu.  The order form can be emailed or snail-mailed to the addresses listed below.

________________________________________________________
Copyright:

WinCraps(TM) is copyrighted by Cloud City Software.  You may share the shareware version of WinCraps with anyone you like, as long as you do not modify the program in any way.  However, sharing or providing your registration number to anyone else is a violation of this copyright.

An extraordinary amount of work has gone into the development of WinCraps.  Please help support this effort and further development by encouraging others to register their own copy of WinCraps.

________________________________________________________
WinCraps includes the following files:

README.TX
HISTORY.TXT
WC50N.EXE
WINCRAPS.HLP
AMBER01.STK thru AMBER17.STK
CANDY01.STK thru CANDY17.STK
STEEN01.STK thru STEEN18.STK
CHATTER.DCE
HARD.DCE
MACHINE.DCE
SOFT.DCE
BLEEP.CHP
BOTTLE.CHP
BUZZ.CHP
CHIP.CHP
CHIRP.CHP
PLUNK.CHP
POP.CHP
SNAP.CHP
SNIP.CHP
CHEERS.WIN
CHIPS.WIN
CROWD.WIN
THUNDER.WIN
SAMPLE1.BET thru SAMPLE13.BET
SAMPLE1.GLG
SAMPLE2.GLG
1LESS772.PRB
1MORE772.PRB
ADD5IN.BET
SUB5IN.BET
HOTKEYS.DTA
MSVBVM60.DLL
MT19937AR.DLL
COKUS.DLL
VB6STKIT.DLL
HOTBITS1.ROL thru HOTBITS3.ROL
FILE_ID.DIZ

________________________________________________________
Disclaimer of Warranty:

CLOUD CITY SOFTWARE DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, AS TO PERFORMANCE, OF MERCHANTABILITY, QUALITY, OR FITNESS FOR A PARTICULAR PURPOSE REGARDING WINCRAPS�.

THE USER MUST ASSUME THE ENTIRE RISK OF INSTALLING AND USING THE PROGRAM. ANY LIABILITY OF CLOUD CITY SOFTWARE WILL BE LIMITED EXCLUSIVELY TO PRODUCT REPLACEMENT OR REFUND OF PURCHASE PRICE TO REGISTERED USERS.

________________________________________________________
Cloud City Software
4035 - 262nd Pl. SE
Issaquah, WA  98029

Email: wincraps@cloudcitysoftware.com
Homepage: http://www.cloudcitysoftware.com
